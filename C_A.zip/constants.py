"""
Auteur     : Selim Kusursuz & Necip Atamnia
Université : Université Paris-Saclay
Projet     : Simulation Épidémique
Date       : 2025
"""


# constants.py

n = 50
p_edge = 0.3
quarantine_rate = 0.02
num_hubs = 20




