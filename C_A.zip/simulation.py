import csv
import tkinter as tk
from tkinter import ttk
from itertools import count
import networkx as nx
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import matplotlib.animation as animation
import random
from datetime import datetime
import threading

from constants import n, p_edge, quarantine_rate, num_hubs
from utils import create_slider


degree_distribution = {
    1: 0.5,  # %20 düğümün 1 bağlantısı olsun
    2: 0.3,  # %50 düğümün 2 bağlantısı olsun
    3: 0.2   # %30 düğümün 3 bağlantısı olsun
}

def custom_graph(n, degree_distribution):
    G = nx.Graph()
    G.add_nodes_from(range(n))

    # Düğümler için dereceleri belirle
    degrees = random.choices(
        population=list(degree_distribution.keys()),
        weights=list(degree_distribution.values()),
        k=n
    )

    # Her düğüm için hedef dereceyi takip etmek için sözlük oluştur
    target_degrees = {node: deg for node, deg in zip(G.nodes, degrees)}

    # Düğümleri karıştırarak bağla
    nodes = list(G.nodes)
    random.shuffle(nodes)

    # Bağlantı oluşturma işlemi
    for node in nodes:
        while G.degree[node] < target_degrees[node]:
            potential_targets = [
                n for n in nodes
                if n != node
                and not G.has_edge(node, n)
                and G.degree[n] < target_degrees[n]
            ]
            
            # Bağlanabilecek düğüm yoksa çık
            if not potential_targets:
                break
                
            target = random.choice(potential_targets)
            G.add_edge(node, target)

    return G



class SimulationApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Simulation Épidémique Interactive")

        control_frame = ttk.Frame(root)
        control_frame.pack(side=tk.TOP, fill=tk.X, padx=10, pady=10)

        self.infection_slider = create_slider(control_frame, "Taux d'infection", 0.01, 3.0, 0.1, 0)
        self.recovery_slider = create_slider(control_frame, "Temps de guérison", 1, 20, 8, 1)
        self.immunity_slider = create_slider(control_frame, "Durée d'immunité", 10, 50, 20, 2)
        self.vaccination_slider = create_slider(control_frame, "Taux de vaccination", 0.0, 0.5, 0.01, 3)

        self.start_button = ttk.Button(control_frame, text="Lancer la simulation", command=self.start_simulation)
        self.start_button.grid(row=4, column=0, columnspan=2, pady=10)

        self.canvas_frame = ttk.Frame(root)
        self.canvas_frame.pack(side=tk.BOTTOM, fill=tk.BOTH, expand=True)

        self.fig, (self.ax1, self.ax2) = plt.subplots(1, 2, figsize=(10, 5))
        self.canvas = FigureCanvasTkAgg(self.fig, master=self.canvas_frame)
        self.canvas_widget = self.canvas.get_tk_widget()
        self.canvas_widget.pack(fill=tk.BOTH, expand=True)

        self.ani = None

    def save_history_to_csv(self, filename=None):
        if filename is None:
            today = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
            filename = f"{today}_simulation_result.csv"

        steps = len(next(iter(self.history.values())))

        with open(filename, mode="w", newline="") as file:
            writer = csv.writer(file)
            writer.writerow(["Temps", "S", "I", "R", "V", "Q"])
            for i in range(steps):
                row = [i] + [self.history[key][i] for key in ["S", "I", "R", "V", "Q"]]
                writer.writerow(row)

    def start_simulation(self):
        if self.ani:
            try:
                self.ani.event_source.stop()
            except Exception:
                pass
            self.ani = None  # Önceki animasyonu sıfırla

        self.ax1.clear()
        self.ax2.clear()

        params = {
            "infection_prob": self.infection_slider.get(),
            "recovery_time": int(self.recovery_slider.get()),
            "immunity_duration": int(self.immunity_slider.get()),
            "vaccination_rate": self.vaccination_slider.get(),
        }

        threading.Thread(target=self.run_simulation, kwargs=params, daemon=True).start()

    def run_simulation(self, infection_prob, recovery_time, immunity_duration, vaccination_rate):
        self.setup_simulation(infection_prob, recovery_time, immunity_duration, vaccination_rate)

        self.ani = animation.FuncAnimation(
            self.fig, self.update, frames=count(), interval=300, repeat=False
        )
        self.canvas.draw()

    def setup_simulation(self, infection_prob, recovery_time, immunity_duration, vaccination_rate):
        self.G = custom_graph(n=n, degree_distribution=degree_distribution)
     
        raw_pos = nx.circular_layout(self.G)
        self.pos = {node: (x * 300, y * 800) for node, (x, y) in raw_pos.items()}
        self.quarantine_edges = {}

        self.color_map = {"S": "blue", "I": "red", "R": "green", "V": "orange", "Q": "purple"}
        self.history = {k: [] for k in self.color_map}

        hub_nodes = random.sample(list(self.G.nodes), num_hubs)
        for node in self.G.nodes:
            self.G.nodes[node].update(state="S", days_infected=0, days_immune=0, days_in_quarantine=0)
            if node not in hub_nodes:
                self.G.add_edge(node, random.choice(hub_nodes))

        patient_zero = random.choice(list(self.G.nodes))
        self.G.nodes[patient_zero]["state"] = "I"

        self.step = 0
        self.infection_prob = infection_prob
        self.recovery_time = recovery_time
        self.immunity_duration = immunity_duration
        self.vaccination_rate = vaccination_rate

    def get_colors(self):
        return [self.color_map.get(self.G.nodes[n]["state"], "gray") for n in self.G.nodes]

    def update(self, frame):
        new_states = {}

        for node in self.G.nodes:
            state = self.G.nodes[node]["state"]
            if state in ["I", "Q"]:
                for neighbor in self.G.neighbors(node):
                    if self.G.nodes[neighbor]["state"] == "S" and random.random() < self.infection_prob:
                        new_states[neighbor] = "I"

        for node in self.G.nodes:
            node_data = self.G.nodes[node]
            state = node_data["state"]

            if state == "I":
                node_data["days_infected"] += 1
                if node_data["days_infected"] >= self.recovery_time:
                    new_states[node] = "R"
                    node_data["days_immune"] = 0

            elif state == "R":
                node_data["days_immune"] += 1
                if node_data["days_immune"] >= self.immunity_duration:
                    new_states[node] = "S"

            elif state == "Q":
                node_data["days_in_quarantine"] += 1
                if node_data["days_in_quarantine"] >= 2:
                    new_states[node] = "I"
                    node_data["days_infected"] = 0
                    self.G.add_edges_from(self.quarantine_edges.pop(node, []))

        susceptibles = [n for n in self.G.nodes if self.G.nodes[n]["state"] == "S"]
        vaccinated = random.sample(susceptibles, int(self.vaccination_rate * len(susceptibles)))
        for v in vaccinated:
            self.G.nodes[v]["state"] = "V"

        for node in self.G.nodes:
            if self.G.nodes[node]["state"] == "I" and random.random() < quarantine_rate:
                self.G.nodes[node]["state"] = "Q"
                self.quarantine_edges[node] = list(self.G.edges(node))
                self.G.remove_edges_from(self.quarantine_edges[node])
                self.G.nodes[node]["days_in_quarantine"] = 0

        for node, state in new_states.items():
            self.G.nodes[node]["state"] = state
            if state in ["S", "I"]:
                self.G.nodes[node]["days_infected"] = 0

        if not any(self.G.nodes[n]["state"] == "I" for n in self.G.nodes):
            print(f"Épidémie terminée au jour {frame + 1}")
            self.ani.event_source.stop()
            self.save_history_to_csv()
            return

        self.ax1.clear()
        nx.draw(self.G, self.pos, node_color=self.get_colors(), node_size=20, ax=self.ax1)
        self.ax1.set_title(f"Étape {frame + 1}")
        self.ax1.axis("off")

        for key in self.history:
            count = sum(1 for n in self.G.nodes if self.G.nodes[n]["state"] == key) / n
            self.history[key].append(count)

        self.ax2.clear()
        for key, values in self.history.items():
            self.ax2.plot(values, label=key, color=self.color_map[key])

        self.ax2.set_ylim(0, 1)
        self.ax2.legend()
        self.ax2.set_title("Évolution")
        self.ax2.set_xlabel("Temps")
        self.ax2.set_ylabel("Proportion")

        self.canvas.draw()

