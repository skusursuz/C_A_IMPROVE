from cellularautomata import GuiCA, CountType
from random import random

TYPE = 0
TIME = 1

BETA = 0.6 		# Probability of catching the disease (COVID).
ALPHA = 0.02    # Generation of a new infection
DISTIME = 5  	# Duration time of the disease (COVID).
RECTIME = 10    # Recover time


def SIR(cell,neighbors):
    match cell[TYPE]:
        case 'Susceptible':
            if CountType(neighbors,'Infectious')  > 0 and random() < BETA:
                return ('Infectious',DISTIME)
            elif random()<ALPHA:
                return('Infectious',DISTIME)
            else:
                return cell 
        case 'Infectious':
            if  cell[TIME] == 0 :
                return ('Recovered', RECTIME)
            else:
            	return ('Infectious', cell[TIME] - 1)
        case 'Recovered':
            if cell[TIME] == 0:
                return ('Susceptible',None)
            else:
                return ('Recovered', cell[TIME]-1)
        case _ :
            return(cell)


cellcolors = {
      ('Empty',None):'white',
      ('Susceptible', None): 'pink',
      ('Infectious', DISTIME):'crimson',
      ('Recovered', RECTIME ): 'orchid'
      }

GuiCA(SIR, cellcolors)
